<?php

class Buscador{
    function unique_multidim_array($array, $key) {
        $temp_array = array();      
        for($i=0;$i<count($array);$i++){           
            $temp_array[$i]=$array[$i][$key];
        }
        return array_unique($temp_array); 
    }
    
 public function BuscarCiudad($data,$Ciudad) {
        $datos=array();
        $z=0;
        for($i=0;$i<count($data);$i++){
            if($Ciudad==$data[$i]){
                $datos[$z]=$data[$i];
                $z++;                
            }
        }
        return($datos);
    }
    
 public function presentavalor($data,$Clave){
        return $this->unique_multidim_array($data,$Clave); 
    }
    
 public function Buscararchivo($data,$RangoPrecio,$Ciudad,$Tipo) {
        $temp_array = array();
        $Rango= explode(";", $RangoPrecio);
        $datos=array();
        $z=0;
        for($i=0;$i<count($data);$i++){
            $Precio=str_replace("$","",$data[$i]["Precio"]);
            $Precio=str_replace(",","",$Precio);
            $Find=0;
            if($Precio>=$Rango[0] and $Precio<=$Rango[1]){
                if($Tipo=='' and $Ciudad<>''){
                    if($Ciudad==$data[$i]["Ciudad"]){
                        $Find=1;                    
                    }
                }
                if($Tipo<>'' and $Ciudad==''){
                    if($Tipo==$data[$i]["Tipo"]){
                        $Find=1;                    
                    }
                }          
                if($Tipo<>'' and $Ciudad<>'' ){
                    if($Ciudad==$data[$i]["Ciudad"] and $Tipo==$data[$i]["Tipo"]){
                        $Find=1;
                    }
                }
                if($Tipo=='' and $Ciudad==''){
                    $Find=1;                    
                }
                if($Find==1){
                    $datos[$z]=$data[$i];
                    $z++;
                }                
            }
        }
        return($datos);
    }
	
    
}