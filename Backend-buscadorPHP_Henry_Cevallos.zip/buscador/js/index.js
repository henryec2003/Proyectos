$('#mostrarTodos').click(presentaregistros);

/*
  Creación de una función personalizada para jQuery que detecta cuando se detiene el scroll en la página
*/

$.fn.scrollEnd = function(callback, timeout) {
  $(this).scroll(function(){
    var $this = $(this);
    if ($this.data('scrollTimeout')) {
      clearTimeout($this.data('scrollTimeout'));
    }
    $this.data('scrollTimeout', setTimeout(callback,timeout));
  });
};
/*
  Función que inicializa el elemento Slider
*/

function inicializarSlider(){
  $("#rangoPrecio").ionRangeSlider({
    type: "double",
    grid: false,
    min: 0,
    max: 100000,
    from: 200,
    to: 80000,
    prefix: "$"
  });
}
/*
  Función que reproduce el video de fondo al hacer scroll, y deteiene la reproducción al detener el scroll
*/
function playVideoOnScroll(){
  var ultimoScroll = 0,
      intervalRewind;
  var video = document.getElementById('vidFondo');
  $(window)
    .scroll((event)=>{
      var scrollActual = $(window).scrollTop();
      if (scrollActual > ultimoScroll){
       video.play();
     } else {
        //this.rewind(1.0, video, intervalRewind);
        video.play();
     }
     ultimoScroll = scrollActual;
    })
    .scrollEnd(()=>{
      video.pause();
    }, 10)
}

//Funcion para cargar todos los datos del archivo JSON despues de dar click en el boton cargar todos
function presentaregistros(){
    $(document).ready(function() {
        $.ajax({
            url: "./data-1.json",
            type: "POST",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            
            success: function(response) {
                presentaresultado(response)
                
            }
        });
    });
}

function presentaresultado(response){
    $('#ResultadosBusqueda').html("");
    $.each(response, function(i, data) {
        $('#ResultadosBusqueda').append(
               "<div class='row col s12 m6'>"
			  + "<div class='card medium'>"
			  +    "<spam class='card-title'><b>Registro Nro:"+data.Id+"</b></spam>"
			  +     "<div class='card-image'>" + "<img src='./img/home.jpg' height='200px' width='80px'></div>"
              +        "<div class='card-content'>"+"<p>Direccion: <b>"+data.Direccion+"</b></p>"
              +                                     "<p>Ciudad: <b>"+data.Ciudad+"</b></p>"
              +                                     "<p>Telefono: <b>"+data.Telefono+"</b></p>"
              +                                     "<p>Codigo_Postal: <b>"+data.Codigo_Postal+"</b></p>"
              +                                     "<p>Tipo: <b>"+data.Tipo+"</b></p>"
              +                                     "<p class='flow-text' style='color:red;'><b>Precio: "+data.Precio+"</b></p>"
			  +         "</div>"
              + "</div>"
			  + "</div>"
          );
      });
}

function CargarCiudadesYTipos(){
    //cargar ciudad y tipo disponibles en el archivo
    $(document).ready(function() {
        $.ajax({
            url: "./modelo/extrae.php",
            type: 'POST',
            dataType: 'json', 
            data: {CargarCiudad: 1,Tipo: 1},
            success: function(data) {
                Object.keys(data.Ciudades).forEach(function(key){     
                    $('#selectCiudad').append("<option value='"+data.Ciudades[key]+"'>"+data.Ciudades[key]+"</option>");                
                });

                Object.keys(data.Tipo).forEach(function(key){     

                    $('#selectTipo').append("<option value='"+data.Tipo[key]+"'>"+data.Tipo[key]+"</option>");                

                });
                $(document).ready(function(){$('#selectCiudad').material_select();});
                $(document).ready(function(){$('#selectTipo').material_select();});
            }
        });
    });
}


$('#submitButton').click(submitInfo);

function submitInfo(event){
    
  event.preventDefault();
  var form_data = getInfoForm();
  $.ajax({
    url: "./modelo/extrae.php",
    dataType: 'json',
    cache: false,
    contentType: false,
    processData: false,
    data: form_data,
    type: 'post',
    success: function(data){
      if (data != "") { 
          console.log(data)
          presentaresultado(data)
      }else {
        alert("No hay resultados para la consulta");
      }
    },
    error: function (xhr, ajaxOptions, thrownError) {
        alert(xhr.status);
        alert(thrownError);
      }
  })
}


function getInfoForm(){
  var form_data = new FormData();
  form_data.append('selectCiudad', $("[id='selectCiudad']").val());
  form_data.append('selectTipo', $("[id='selectTipo']").val());
  form_data.append('rangoPrecio', $("[id='rangoPrecio']").val());
  
  return form_data;
}

inicializarSlider();
CargarCiudadesYTipos();
playVideoOnScroll();
$(document).ready(function(){$('#selectCiudad').material_select();});
$(document).ready(function(){$('#selectTipo').material_select();});
