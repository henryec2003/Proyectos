<?php
require_once '../control/datos.php';

$data = file_get_contents("../data-1.json");
$archivo = json_decode($data, true);
$obBuscador=new Buscador();
if(isset($_REQUEST["CargarCiudad"])){
    $DatosCiudades=$obBuscador->presentavalor($archivo,"Ciudad");
    $DatosTipo=$obBuscador->presentavalor($archivo,"Tipo");
    $Array['Ciudades']=$DatosCiudades;
    $Array['Tipo']=$DatosTipo;
    echo json_encode($Array);
}

if(isset($_REQUEST["rangoPrecio"])){    
    $RangoPrecio=$_REQUEST["rangoPrecio"];    
    $Ciudad=$_REQUEST["selectCiudad"];
    $Tipo=$_REQUEST["selectTipo"];
    $Resultado=$obBuscador->Buscararchivo($archivo, $RangoPrecio,$Ciudad,$Tipo);
    if($Resultado==''){
        $Resultado["Error"]="No exiten datos en la busqueda";
    }
    echo json_encode($Resultado);
}