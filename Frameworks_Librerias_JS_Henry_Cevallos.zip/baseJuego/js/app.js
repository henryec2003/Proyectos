var continuar;
var puntaje;
var movimientos;
var MovimientosInterval;

$(function(){

 function parpadea(selector) {
	$(selector).animate({
			opacity: '1',
		}, {
			step: function () {
				$(this).css('color', 'white');
			},
			queue: true
		})
		.animate({
			opacity: '1'
		}, {
			step: function () {
				$(this).css('color', 'yellow');
			},
			queue: true
		}, 600)
		.delay(1000)
		.animate({
			opacity: '1'
		}, {
			step: function () {
				$(this).css('color', 'white');
			},
			queue: true
		})
		.animate({
			opacity: '1'
		}, {
			step: function () {
				$(this).css('color', 'yellow');
				parpadea('h1.main-titulo');
			},
			queue: true
		});
}

      $('.col-1').droppable({
         accept: ".col-2"
     });
     $('.col-2').droppable({
         accept: ".col-1, .col-3"
     });
     $('.col-3').droppable({
         accept: ".col-2, .col-4"
     });
     $('.col-4').droppable({
         accept: ".col-3, .col-5"
     });
     $('.col-5').droppable({
         accept: ".col-4, .col-6"
     });
     $('.col-6').droppable({
         accept: ".col-5, .col-7",
         drop: function (event, ui) {
             console.log($(this).attr("src"));
         }
     });
     $('.col-7').droppable({
         accept: ".col-6"
     });

     $('.btn-reinicio').click(function () {
         if ($('.btn-reinicio').text() === 'Iniciar') {
             if ($(".panel-tablero").css('display') === 'none') {
                 $(".panel-tablero").css('display', 'flex');
                 $(".panel-tablero").css('width', '70%');
                 $(".panel-tablero").css('height', '700px');
                 $(".panel-score").css('display', 'flex');
                 $(".panel-score").css('width', '25%');
                 $(".panel-score").css('height', '700px');
                 $(".time").css('display', 'block');
                 $(".time").css('width', '100%');
                 $(".time").css('height', '23%');
                 $(".time").css('opacity', '1.0');
             }

             $('.juego-terminado').css("display","none");
             puntaje = 0;
             movimientos = 0;
             parpadea('h1.main-titulo');
             removercol();
             rellenarmatriz();
             iniciaJuego();
             $(this).text('Reiniciar');
             $('#movimientos-text').text('0');
         }
         else {
             clearInterval(MovimientosInterval);
             $('#timer').countdowntimer({
                 minutes: 0,
                 seconds: 0
             });
             $(this).text('Iniciar');
             $('#score-text').text('0');
         }
     });
 });

 function removercol() {
     for (var columna = 1; columna <= 7; ++columna) {
         $('.col-' + columna).empty();
     }
 }

 function rellenarmatriz() {
     for (var columna = 1; columna <= 7; ++columna) {
         for (var fila = 1; fila <= 7; ++fila) {
             var Imagen = $('<img>',
                 {"src": "image/" + (1 + Math.floor(Math.random() * 4)) + ".png", "class": "elemento"}
             );
             $(Imagen).draggable();
             $('.col-' + columna).append(Imagen);
         }
     }
 }

 function iniciaJuego() {
     continuar = true;
     draganddrop();

     $('#timer').countdowntimer({
         minutes: 2,
         seconds: 0,
         timeUp: function () {
             continuar = false;
             clearInterval(realizarMovimientos());

             var anchoPanelTablero = $('.panel-tablero').css('width');

             $(".panel-tablero").animate({
                 height: "0",
                 width: "0"
             }, 4100, function () {
                 $(".panel-tablero").css('display', 'none');
             });

             $('.panel-score').animate({
                 width: anchoPanelTablero
             }, 3000);

             $('.time').animate({
                 opacity: 0.0
             }, 2000);

             $('.btn-reinicio').text('Iniciar');

             $('.juego-terminado').css("display", "block")
         }
     });

     MovimientosInterval = setInterval(realizarMovimientos, 1500);
 }

 function actualizanromov() {
     movimientos += 1;
     $('#movimientos-text').text(movimientos);
 }

 function intercambiaimagen(elm1, elm2) {
     var parent1, next1,
         parent2, next2;

     parent1 = elm1.parentNode;
     next1 = elm1.nextSibling;
     parent2 = elm2.parentNode;
     next2 = elm2.nextSibling;

     parent1.insertBefore(elm2, next1);
     parent2.insertBefore(elm1, next2);
 }

 function realizarMovimientos() {

     var contador;
     var nombreImagen;
     var nombreImagenSgte;
     var figurasMarcadas = llenarfiguras();
     var cambiar = false;

     for (var fila = 0; fila < 7; ++fila) {
         for (var columna = 0; columna < 7; ++columna) {
             if ((7 - columna) > 2) {
                 nombreImagen = $('.col-' + (columna + 1)).children()[fila];
                 nombreImagen = $(nombreImagen).prop('src').substring($(nombreImagen).prop('src').length - 5);

                 contador = 1;

                 while ((7 - columna) >= 3 && contador < (7 - columna)) {
                     nombreImagenSgte = $('.col-' + (columna + contador + 1)).children()[fila];
                     nombreImagenSgte = $(nombreImagenSgte).prop('src').substring($(nombreImagenSgte).prop('src').length - 5);

                     if (nombreImagen !== nombreImagenSgte) {
                         break;
                     }

                     ++contador;
                 }

                 if (contador >= 3) {
                     cambiar = true;
                     for (var i = 0; i < contador; ++i) {
                         figurasMarcadas[fila][columna + i] = true;
                     }
                 }
             }

             if ((7 - fila) > 2) {
                 nombreImagen = $('.col-' + (columna + 1)).children()[fila];
                 nombreImagen = $(nombreImagen).prop('src').substring($(nombreImagen).prop('src').length - 5);

                 contador = 1;

                 while ((7 - fila) >= 3 && contador < (7 - fila)) {
                     nombreImagenSgte = $('.col-' + (columna + 1)).children()[fila + contador];
                     nombreImagenSgte = $(nombreImagenSgte).prop('src').substring($(nombreImagenSgte).prop('src').length - 5);

                     if (nombreImagen !== nombreImagenSgte) {
                         break;
                     }

                     ++contador;
                 }

                 if (contador >= 3) {
                     cambiar = true;
                     for (var i = 0; i < contador; ++i) {
                         figurasMarcadas[fila + i][columna] = true;
                     }
                 }
             }
         }
     }

     if (cambiar) {
         actualizarmatriz(figurasMarcadas);
     } else {
         clearInterval(MovimientosInterval);
     }
 }


 function llenarfiguras() {
     var figurasMarcadas = [];

     for (var fila = 0; fila < 7; ++fila) {
         figurasMarcadas[fila] = new Array(7);
         for (var columna = 0; columna < 7; ++columna) {
             figurasMarcadas[fila][columna] = false;
         }
     }

     return figurasMarcadas;
 }

 function actualizarmatriz(figurasMarcadas) {
     var puntaje = 0;
     for (var columna = 0; columna < 7; ++columna) {
         for (var fila = 0; fila < 7; ++fila) {
             if (figurasMarcadas[fila][columna]) {
                 $($('.col-' + (columna + 1)).children()[fila]).addClass('remover');
                 puntaje += 10;
             }
         }
     }

     if ($('.remover').length > 0) {
         $('.remover').fadeIn(400).fadeOut(400).fadeIn(400).fadeOut(300, function () {
             $(this).remove();

             actualizapuntuacion(puntaje);
             nuevaimagen();
         });
     }
 }

 function nuevaimagen() {
     for (var col = 0; col < 7; ++col) {
         if ($('.col-' + (col + 1)).children().length < 7) {
             var numeroDulces = 7 - $('.col-' + (col + 1)).children().length;

             for (var i = 1; i <= numeroDulces; ++i) {
                 var nuevoDulce = $('<img>',
                     {"src": "image/" + (1 + Math.floor(Math.random() * 4)) + ".png", "class": "elemento"});
                 $('.col-' + (col + 1)).prepend(nuevoDulce);
             }
         }
     }

     draganddrop();
 }

 function actualizapuntuacion(masPuntaje) {
     puntaje += masPuntaje;
     $('#score-text').text(puntaje);
 }

 function draganddrop() {
     $(".elemento").draggable({
         disabled: false,
         cursor: "move",
         containment: ".panel-tablero",
         revert: true,
         revertDuration: 500,
         snap: ".elemento",
         snapMode: "inner",
         snapTolerance: 40,
         stop: function (event, ui) {

             actualizanromov();
         }
     });
     $(".elemento").droppable({
         drop: function (event, ui) {
             if (MovimientosInterval !== 0) {
                 var dropped = ui.draggable;
                 var droppedOn = this;

                 var colDropped = Number($($(dropped).parent()).attr("class").substring(4, 5));
                 var colDroppedOn = Number($($(droppedOn).parent()).attr("class").substring(4, 5));

                 if ((Math.abs(colDropped - colDroppedOn) === 1) || colDroppedOn === colDropped) {
                     intercambiaimagen(dropped[0], droppedOn);
                     MovimientosInterval = setInterval(realizarMovimientos, 1500);
                 }
             }
         }
     });
 }
