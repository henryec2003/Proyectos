var pantalla = document.getElementById('display');
document.onkeydown = teclado;

x = "0";
xi = 1;
coma = 0;
ni = 0;
op = "no";

function numero(xx) { //recoge el número pulsado
    pulsar(xx);
    if (x == "0" || xi == 1) {

        pantalla.innerHTML = xx;
        x = xx;
        if (xx == ".") {

            pantalla.innerHTML = "0.";
            x = xx;
            coma = 1;
        }
    } else {
        if (xx == "." && coma == 0) {

            pantalla.innerHTML += xx;
            x += xx;
            coma = 1;
        }

        else if (xx == "." && coma == 1) {}

        else {
            pantalla.innerHTML += xx;
            x += xx
        }
    }
    xi = 0
}
//operaciones fundamentales.
function operar(s) {
    operandos(s);
    igualar();
    ni = x
    op = s;
    xi = 1;

}
//cuando se pulsa el igual
function igualar() {
  pulsarigual();
    if (op == "no") {
        pantalla.innerHTML = x;
    } else {
        sl = ni + op + x;
        sol = eval(sl)
        pantalla.innerHTML = sol
        x = sol;
        op = "no";
        xi = 1;
    }
}
//pone el negativo
function opuest() {
  pulsarnegativo();
    nx = Number(x);
    nx = -nx;
    x = String(nx);
    pantalla.innerHTML = x;
}
//resolver raíz cuadrada
function raizc() {
    x = Math.sqrt(x) .
    pantalla.innerHTML = x;
    op = "no";
    xi = 1;
}

//borrar pantalla
function on() {
   pulsaron();
    pantalla.innerHTML = 0;
    x = "0";
    coma = 0;
    ni = 0
    op = "no"
}

//eventos del teclado
function teclado(elEvento) {
    evento = elEvento || window.event;
    k = evento.keyCode;

    if (k > 47 && k < 58) {
        p = k - 48;
        p = String(p)
        numero(p);
    }
    //Teclas del teclado númerico. Seguimos el mismo procedimiento que en el anterior.
    if (k > 95 && k < 106) {
        p = k - 96;
        p = String(p);
        numero(p);
    }
    if (k == 110 || k == 190) { numero(".") }
    if (k == 106) { operar('*') }
    if (k == 107) { operar('+') }
    if (k == 109) { operar('-') }
    if (k == 111) { operar('/') }
    if (k == 32 || k == 13) { igualar() }
    if (k == 46) { on() }
}

//pulsar teclado con mouse
function pulsar(xx) {
    if (xx == "1") {
        document.getElementById("1").addEventListener("mousedown", smallImg('1'));
        setTimeout(() => {
            document.getElementById("1").addEventListener("mouseup", normalImg('1'));
        }, 100);
    }
    if (xx == "2") {
        document.getElementById("2").addEventListener("mousedown", smallImg('2'));
        setTimeout(() => {
            document.getElementById("2").addEventListener("mouseup", normalImg('2'));
        }, 100);
    }

    if (xx == "3") {
        document.getElementById("3").addEventListener("mousedown", smallImg('3'));
        setTimeout(() => {
            document.getElementById("3").addEventListener("mouseup", normalImg('3'));
        }, 100);
    }

    if (xx == "4") {
        document.getElementById("4").addEventListener("mousedown", smallImg('4'));
        setTimeout(() => {
            document.getElementById("4").addEventListener("mouseup", normalImg('4'));
        }, 100);
    }

    if (xx == "5") {
        document.getElementById("5").addEventListener("mousedown", smallImg('5'));
        setTimeout(() => {
            document.getElementById("5").addEventListener("mouseup", normalImg('5'));
        }, 100);
    }

    if (xx == "6") {
        document.getElementById("6").addEventListener("mousedown", smallImg('6'));
        setTimeout(() => {
            document.getElementById("6").addEventListener("mouseup", normalImg('6'));
        }, 100);
    }

    if (xx == "7") {
        document.getElementById("7").addEventListener("mousedown", smallImg('7'));
        setTimeout(() => {
            document.getElementById("7").addEventListener("mouseup", normalImg('7'));
        }, 100);
    }

    if (xx == "8") {
        document.getElementById("8").addEventListener("mousedown", smallImg('8'));
        setTimeout(() => {
            document.getElementById("8").addEventListener("mouseup", normalImg('8'));
        }, 100);
    }

    if (xx == "9") {
        document.getElementById("9").addEventListener("mousedown", smallImg('9'));
        setTimeout(() => {
            document.getElementById("9").addEventListener("mouseup", normalImg('9'));
        }, 100);
    }

    if (xx == "0") {
        document.getElementById("0").addEventListener("mousedown", smallImg('0'));
        setTimeout(() => {
            document.getElementById("0").addEventListener("mouseup", normalImg('0'));
        }, 100);
    }
    if (xx == ".") {
        document.getElementById("punto").addEventListener("mousedown", smallImg('.'));
        setTimeout(() => {
            document.getElementById("punto").addEventListener("mouseup", normalImg('.'));
        }, 100);
    }

}

//pulsa la tecla igual con el mouse
function pulsarigual(){
    document.getElementById("igual").addEventListener("mousedown", smallImg('='));
    setTimeout(() => {
        document.getElementById("igual").addEventListener("mouseup", normalImg('='));
    }, 100);
}

//pulsa la tecla del negativo con el mouse
function pulsarnegativo(){
    document.getElementById("sign").addEventListener("mousedown", smallImgneg);
    setTimeout(() => {
        document.getElementById("sign").addEventListener("mouseup", normalImgneg);
    }, 100);
}

//pulsa la tecla del on con el mouse
function pulsaron(){
    document.getElementById("on").addEventListener("mousedown", smallImgon);
    setTimeout(() => {
        document.getElementById("on").addEventListener("mouseup", normalImgon);
    }, 100);
}

//pulsa la tecla de los operandos con el mouse

function operandos(s){
  if (s == "/") {
    document.getElementById("dividido").addEventListener("mousedown", smallImg('/'));
    setTimeout(() => {
        document.getElementById("dividido").addEventListener("mouseup", normalImg('/'));
    }, 100);
  }
  if (s == "+") {
    document.getElementById("mas").addEventListener("mousedown", smallImg('+'));
    setTimeout(() => {
        document.getElementById("mas").addEventListener("mouseup", normalImg('+'));
    }, 100);
  }

  if (s == "-") {
    document.getElementById("menos").addEventListener("mousedown", smallImg('-'));
    setTimeout(() => {
        document.getElementById("menos").addEventListener("mouseup", normalImg('-'));
    }, 100);
  }

  if (s == "*") {
    document.getElementById("por").addEventListener("mousedown", smallImg('*'));
    setTimeout(() => {
        document.getElementById("por").addEventListener("mouseup", normalImg('*'));
    }, 100);
  }
}

//reduce la imagen
function smallImg(xx) {
    var altura = "height:62.91px !important";
    var ancho = "width:20%";
    if (xx == "1") {

        document.getElementById("1").style = altura;
        document.getElementById("1").style = "width:28%";
    }
    if (xx == "2") {
        document.getElementById("2").style = altura;
        document.getElementById("2").style = "width:28%";
    }

    if (xx == "3") {
        document.getElementById("3").style = altura;
        document.getElementById("3").style = "width:28%";
    }

    if (xx == "4") {
        document.getElementById("4").style = altura;
        document.getElementById("4").style = ancho;
    }

    if (xx == "5") {
        document.getElementById("5").style = altura;
        document.getElementById("5").style = ancho;
    }

    if (xx == "6") {
        document.getElementById("6").style = altura;
        document.getElementById("6").style = ancho;
    }

    if (xx == "7") {
        document.getElementById("7").style = altura;
        document.getElementById("7").style = ancho;
    }

    if (xx == "8") {
        document.getElementById("8").style = altura;
        document.getElementById("8").style = ancho;
    }

    if (xx == "9") {
        document.getElementById("9").style = altura;
        document.getElementById("9").style = ancho;
    }

    if (xx == "0") {
        document.getElementById("0").style = altura;
        document.getElementById("0").style = "width:28%";
    }

    if (xx == ".") {
        document.getElementById("punto").style = altura;
        document.getElementById("punto").style = "width:28%";
    }

    if (xx == "=") {
        document.getElementById("igual").style = altura;
        document.getElementById("igual").style = "width:28%";
    }

    if (xx == "/") {
        document.getElementById("dividido").style = altura;
        document.getElementById("dividido").style = ancho;
    }

    if (xx == "+") {
        document.getElementById("mas").style = "height:97%";
        document.getElementById("mas").style = "width: 88%";
    }

    if (xx == "-") {
        document.getElementById("menos").style = altura;
        document.getElementById("menos").style = ancho;
    }

    if (xx == "*") {
        document.getElementById("por").style = altura;
        document.getElementById("por").style = ancho;
    }
}

//vuelve a estado normal
function normalImg(xx) {
  var altura = "height:62.91px !important";
  var ancho = "width:22%";
    if (xx == "1") {
        document.getElementById("1").style = altura;
        document.getElementById("1").style = "width:29%";
    }
    if (xx == "2") {
        document.getElementById("2").style = altura;
        document.getElementById("2").style = "width:29%";
    }

    if (xx == "3") {
        document.getElementById("3").style = altura;
        document.getElementById("3").style = "width:29%";
    }

    if (xx == "4") {
        document.getElementById("4").style = altura;
        document.getElementById("4").style = ancho;
    }

    if (xx == "5") {
        document.getElementById("5").style = altura;
        document.getElementById("5").style = ancho;
    }

    if (xx == "6") {
        document.getElementById("6").style = altura;
        document.getElementById("6").style = ancho;
    }

    if (xx == "7") {
        document.getElementById("7").style = altura;
        document.getElementById("7").style = ancho;
    }

    if (xx == "8") {
        document.getElementById("8").style = altura;
        document.getElementById("8").style = ancho;
    }

    if (xx == "9") {
        document.getElementById("9").style = altura;
        document.getElementById("9").style = ancho;
    }

    if (xx == "0") {
        document.getElementById("0").style = altura;
        document.getElementById("0").style = "width:29%";
    }

    if (xx == ".") {
        document.getElementById("punto").style = altura;
        document.getElementById("punto").style = "width:29%";
    }

    if (xx == "=") {
        document.getElementById("igual").style = altura;
        document.getElementById("igual").style = "width:29%";
    }

    if (xx == "/") {
        document.getElementById("dividido").style = altura;
        document.getElementById("dividido").style = ancho;
    }

    if (xx == "+") {
        document.getElementById("mas").style = "height:100%";
        document.getElementById("mas").style = "width:90%";
    }

    if (xx == "-") {
        document.getElementById("menos").style = altura;
        document.getElementById("menos").style = ancho;
    }

    if (xx == "*") {
        document.getElementById("por").style = altura;
        document.getElementById("por").style = ancho;
    }

}

function smallImgneg(){
    document.getElementById("sign").style = "height:62.91px !important";
    document.getElementById("sign").style = "width:20%";
}

function normalImgneg(){
    document.getElementById("sign").style = "height:62.91px !important";
    document.getElementById("sign").style = "width:22%";
}

function smallImgon(){
    document.getElementById("on").style = "height:62.91px !important";
    document.getElementById("on").style = "width:20%";
}

function normalImgon(){
    document.getElementById("on").style = "height:62.91px !important";
    document.getElementById("on").style = "width:22%";
}
