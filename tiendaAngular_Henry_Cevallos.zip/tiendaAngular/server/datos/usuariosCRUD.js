var Usuario = require('./usuarioModel.js');
module.exports.insertarUsuario = function (callback) {
	let User1 = new Usuario({nombre: "usuario 1", email: 'user1@tiendaangularnextu.com', password:'user1234'});
	
	User1.save((error) => {
		if(error) callback(error);
		callback(null,"Usuario Ingresado usuariosCrud.js");
	});
};

module.exports.eliminarUsuario = function (callback) {	
	Usuario.remove({email: 'user1@tiendaangularnextu.com'}, (error) => {
		if(error) callback(error);
		callback(null,"Registro eliminado usuarios crud.js");
	});
};

module.exports.consultarUsuario = function (data, callback) {
	Usuario.findOne({email: data.email}, (err, user) => {
		if(user){
			if(user.password === data.password)
				callback(null,user);
      		else
      			callback('Password incorrecto -usuarioscrud.js-');
      	} else
			callback('Usuario no existe');
	});
};