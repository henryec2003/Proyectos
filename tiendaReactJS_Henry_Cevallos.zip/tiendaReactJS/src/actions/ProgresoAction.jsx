import Reflux from 'reflux';

let ProgresoAction = Reflux.createActions(
		[
			'mostrarProgreso'
		]
	);

export default ProgresoAction;